from django.apps import AppConfig


class QuizsystemConfig(AppConfig):
    name = 'QuizSystem'
