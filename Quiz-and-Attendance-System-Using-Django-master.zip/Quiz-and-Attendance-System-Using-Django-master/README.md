"# Quiz-and-Attendance-System-Using-Django" 

Being a web-based project, the proposed Quiz and Attendance system aims at providing an online comprehensive platform for management of quiz competitions as well as the individuals participating in quiz as a team and it is also developed for daily student attendance in schools, colleges. It facilitates to access the attendance information of a particular student in a particular class.This system will also help in evaluating attendance criteria of a student.

This project has three modules:
admin
teacher
student

Admin Module:-

Dashboard: In this section, admin can view and manage all brief information total reg students, total reg staff, total class listed.

Teacher Module:-

-Teacher can mark the attendance of class

-Generate reports

-Manage own profile

-change Password

-Create Quiz Paper.

Student  Module:-

-Dashboard 

-Able to attend Quiz

-monitor own attendance and quiz result 

-update own profile

-change password

Technology used:-

-Front end: HTML, CSS, JavaScript, Bootstrap

-Back end: Python Django


